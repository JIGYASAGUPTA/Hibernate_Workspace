package com;

import java.util.*;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.mapping.List;

import com.Employee;
import com.EmployeeAtt;
import com.maruthi.Answer;
import com.maruthi.Question;





public class EmployeeDAO {
	
	
	public  int CheckEmployee(String id,String pas)
	{
		

		Session session = HibernateUtil.openSession();
		Transaction	tx = session.getTransaction();
        tx.begin();
		
		String hql="From Employee e  where e.getID() ="+id+"and e.getPass()="+pas+""; //emaild --->id
		Query query = session.createQuery(hql);
		List results = (List) query.list();
		
		int count=((Query) results).executeUpdate();
		
		
		 
         tx.commit();
         
     return count;
         
         
         
	}
	
	
	public void Addemployee(Employee e)
	{
		
		Session session = HibernateUtil.openSession();
		Transaction trans = null;
		try 
		{
			trans = session.beginTransaction();
			Employee emp = new Employee();
			//since setters and getters are associated, so just create an object and set the name and marks using setters
			emp.setEmailId(e.getEmailId());
			emp.setFname(e.getFname());
			emp.setLname(e.getLname());
			emp.setPasswd(e.getPasswd());
			
			session.persist(emp);
			//session.s
			trans.commit();
			session.clear();
			session.close();
			//session.s
			
			
			//name,mob
			
			//use hashtable to enter the data
			//key=name,val=mobile
			
			
			
			
		} 
		catch (HibernateException ex) {
			if (trans != null) {
				trans.rollback();
				ex.printStackTrace();
			}
		} finally {
			session.close();
		}
	}
	
	

	

	
	public void punchIn(EmployeeAtt et)//emailid, datetime,true=>ppunchin,false=>punchout column
	{
		
		Session session = HibernateUtil.openSession();
		Transaction trans = null;
		try 
		{
			trans = session.beginTransaction();
			EmployeeAtt att = new EmployeeAtt();
			//since setters and getters are associated, so just create an object and set the name and marks using setters
			att.setEmailid(et.getEmailid());
			att.setDate(et.getDate());
			
			
			session.persist(att);
			//session.s
			trans.commit();
			session.clear();
			session.close();
			//session.s
			
			
			//name,mob
			
			//use hashtable to enter the data
			//key=name,val=mobile
			
			
		} 
		catch (HibernateException ex) {
			if (trans != null) {
				trans.rollback();
				ex.printStackTrace();
			}
		} finally {
			session.close();
		}
		
		
		//session.persist(et);
	}
	//
	
	
	
	
	public void punchOut(EmployeeAtt et)//emailid, datetime,true=>ppunchin,false=>punchout column
	{
		
		Session session = HibernateUtil.openSession();
		Transaction trans = null;
		try 
		{
			trans = session.beginTransaction();
			EmployeeAtt att = new EmployeeAtt();
			//since setters and getters are associated, so just create an object and set the name and marks using setters
			att.setEmailid(et.getEmailid());
			att.setDate(et.getDate());
			
			
			session.persist(att);
			//session.s
			trans.commit();
			session.clear();
			session.close();
			//session.s
			
			
			//name,mob
			
			//use hashtable to enter the data
			//key=name,val=mobile
			
			
		} 
		catch (HibernateException ex) {
			if (trans != null) {
				trans.rollback();
				ex.printStackTrace();
			}
		} finally {
			session.close();
		}
		
		
		//session.persist(et);
	}
	//
	
	
	public  int getPunchInDate(String email ){
		
		Session session = HibernateUtil.openSession();
		Transaction	tx = session.getTransaction();
        tx.begin();
		
		String hql="'From EmployeeAtt e.Date  where e.emailId ='"+email+"'order by e.Date desc limit 1'"; //emaild --->id
		Query query = session.createQuery(hql);
		List results = (List) query.list();
		
		//select e.getPunchinDate() from Employeeatt e  where e.emaild ='"+email+"' order by punchindate desc limit 1;
		
		
		return 0;
	}
	
	public Employee getEmployeeByEmail(String email)
	{
		
		
		return null;
	}
	//inside JSP pa
	
	
	//
	
	
public List getAllRecords(String email ){
	Session session = HibernateUtil.openSession();
		
	
	Transaction	tx = session.getTransaction();
    tx.begin();
   
    //java.util.List<EmployeeAtt> results = new ArrayList<EmployeeAtt>();
    
	
	String hql= "From Employee"; //emaild --->id
	Query query = session.createQuery(hql);
   // java.util.List results = query.list();
     List result = (List) query.list();
    
     
    
	
	Iterator<Employee> itr=((java.util.List) result).iterator();
	 
	while(itr.hasNext()){
		Employee q=itr.next();
		//System.out.println("Question Name: "+q.getQname());
		
		
		//printing answers
		List<Answer> list2=q.getAnswers();
		Iterator<Answer> itr2=list2.iterator();
		while(itr2.hasNext()){
			System.out.println(itr2.next());
		}	
	}
	session.close();
     
	

	 
 	
 	
 	session.close();
 	System.out.println("success");
 	 return result;
 	
	

	
	
	 
     tx.commit();
     

		
		//select e.getPunchinDate() from Employeeatt e  where e.emaild ='"+email+"' order by punchindate desc limit 1;
		
		
		return results;
	}
	
	

	public  int getPunchOutDate(){
		
		return 0;
		
	}
	
	

	
}
